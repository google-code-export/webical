#!/bin/bash
echo "building source"
javac -classpath .:/home/ivo/workspace-3.2/PluginFrameworkPOCStory/src/main/java/:/home/ivo/.m2/repository/wicket/wicket/1.2.1/wicket-1.2.1.jar:/home/ivo/.m2/repository/wicket/wicket-extensions/1.2.1/wicket-extensions-1.2.1.jar *.java
javac -classpath .:/home/ivo/workspace-3.2/PluginFrameworkPOCStory/src/main/java/:/home/ivo/.m2/repository/wicket/wicket/1.2.1/wicket-1.2.1.jar:/home/ivo/.m2/repository/wicket/wicket-extensions/1.2.1/wicket-extensions-1.2.1.jar somePackage/*.java

echo "creating package"
zip -r example-plugin.zip *
