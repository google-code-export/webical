package somePackage;

class SomeOtherClass {

}
