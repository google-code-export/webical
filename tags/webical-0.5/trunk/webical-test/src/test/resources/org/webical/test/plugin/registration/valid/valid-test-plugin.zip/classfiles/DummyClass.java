class DummyClass {

}
