import org.webical.web.event.Extension;
import org.webical.web.event.ExtensionEvent;
import org.webical.web.event.ExtensionHandler;
import org.webical.web.event.ExtensionListener;

import wicket.Component;
import wicket.extensions.markup.html.tabs.AbstractTab;

public class SomeExtension implements ExtensionListener, ExtensionHandler {

	public void addExtensionsAfterComponentSetup(ExtensionEvent extensionEvent) {
		// TODO Auto-generated method stub
		
	}

	public void addExtensionsBeforeComponentSetup(ExtensionEvent extensionEvent) {
		// TODO Auto-generated method stub
		
	}

	public void addExtension(Extension extension) {
		// TODO Auto-generated method stub
		
	}

	public void addExtensionListener(ExtensionListener extensionListener) {
		// TODO Auto-generated method stub
		
	}

	public void addReplaceableComponent(String componentId) {
		// TODO Auto-generated method stub
		
	}

	public void addTabToTabbedPanel(AbstractTab tab) {
		// TODO Auto-generated method stub
		
	}

	public void removeExtensionListener(ExtensionListener extensionListener) {
		// TODO Auto-generated method stub
		
	}

	public void replaceExistingComponentWithExtension(Component extensionComponent) {
		// TODO Auto-generated method stub
		
	}

}
