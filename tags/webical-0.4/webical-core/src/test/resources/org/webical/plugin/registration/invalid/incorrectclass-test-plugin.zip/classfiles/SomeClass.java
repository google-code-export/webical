import java.util.Date;
import java.util.List;

import org.webical.Calendar;
import org.webical.Event;
import org.webical.dao.DaoException;
import org.webical.dao.EventDao;

public class SomeClass implements EventDao {
	
	public SomeClass() {}

	public List<Event> getAllEvents(Calendar calendar) throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Event> getEventsForPeriod(Calendar calendar, Date dtStart, Date dtEnd) throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}

	public void removeAllEvents(List<Event> events) throws DaoException {
		// TODO Auto-generated method stub
		
	}

	public void removeEvent(Event event) throws DaoException {
		// TODO Auto-generated method stub
		
	}

	public void storeEvent(Event event) throws DaoException {
		// TODO Auto-generated method stub
		
	}

	public void storeEvents(List<Event> events) throws DaoException {
		// TODO Auto-generated method stub
		
	}

}
